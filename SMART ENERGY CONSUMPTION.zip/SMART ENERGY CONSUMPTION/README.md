# Wattwise — Smart Energy Consumption

A browser-based energy website with separate customer and admin accounts. The Python server protects sign-in, customer records, and energy data with SQLite-backed role checks. It uses only Python's standard library; no `pip install` is needed.

The included energy readings are illustrative sample data, not readings from a live meter.

## Requirements

- Python 3.10 or later
- A web browser
- R (optional, only for the analysis script)

If `python` is not recognized in PowerShell, install Python 3 for Windows and select **Add python.exe to PATH** during setup, then reopen PowerShell.

## First-time setup

Double-click `run-website.bat`. It finds an installed Python runtime, starts the website, and opens it in your browser. The first time you visit, create both accounts and choose separate passwords of at least 12 characters in the browser. Account setup only accepts requests from your computer; passwords are stored as salted hashes.

Sign in with `divyanshusingh31113@gmail.com` for the admin workspace or `thehorrorofcentury@gmail.com` for the customer dashboard. Open [http://127.0.0.1:8001](http://127.0.0.1:8001) to return to the website. This separate port prevents VS Code's static preview on port 8000 from being mistaken for the actual website.

To start the service manually instead, open PowerShell in the project folder and run `python server.py`. Then open [http://127.0.0.1:8001](http://127.0.0.1:8001). If `python` is not recognized in the terminal, the `run-website.bat` launcher also checks the Python runtime installed with VS Code.

## Admin and customer access

- **Admin:** Add customer accounts, review their usage summaries and individual readings, reset customer passwords, remove customer accounts, and create additional admin accounts. Passwords must be at least 12 characters; share temporary passwords privately.
- **Customer:** Sign in with an admin-provided account to see only that account's own readings.
- There is no public registration or role selector. The server assigns the dashboard from the signed-in account's role.
- Creating a customer seeds that customer's separate account with the included sample readings. Share any temporary password securely.
- The appliance breakdown is clearly marked as an illustrative estimate. Actual individual-appliance readings require connected device meters.

The SQLite database is created at `instance/wattwise.sqlite3`. It contains account password hashes, sessions, and per-customer readings. Back up this file securely if you need to preserve accounts and changes.

## Running the R analysis (optional)

Run this command from the project folder if R is installed:

```powershell
Rscript energy_analysis.R
```

The script validates `data/energy_usage.csv` and writes daily and weekly summaries to the `analysis` folder.

## Important deployment note

The included server is intended for local project use and binds to `127.0.0.1` by default. It is not a production hosting server and should not be exposed directly to the internet. Adding an admin account grants access only when the website is reachable; this local setup cannot be reached from a different device. For remote use, deploy behind a production-ready HTTPS server and set `WATTWISE_SECURE_COOKIE=1`; use suitable backups, access controls, and security monitoring.

## Project files

- `server.py` — Python web server, SQLite database, sign-in, and protected APIs
- `run-website.bat`, `run-website.ps1` — Windows launcher that sets up the requested accounts and starts the web server
- `login.html`, `login.js` — shared sign-in and secure first-run account setup; account role determines where the user goes
- `index.html`, `app.js` — customer dashboard and private energy summaries
- `admin.html`, `admin.js` — admin customer/account management
- `styles.css`, `auth.css` — responsive website styling
- `auth.js` — authenticated browser requests and sign-out
- `data/energy_usage.csv` — sample readings copied into each newly created customer account
- `energy_analysis.R` — optional R data analysis
- `tests/test_server.py` — authentication, role access, account setup, password reset, and session integration tests

## Run the tests

From a terminal with Python installed, run:

```powershell
python -m unittest discover -s tests -v
```
